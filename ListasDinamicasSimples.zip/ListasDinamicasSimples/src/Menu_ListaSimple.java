public class Menu_ListaSimple {
    public static void main(String args []){
        OperListaSimple lista = new OperListaSimple();


        lista.addPrimero("Luis");
        lista.addPrimero(2);
        lista.addPrimero(3);
        lista.addPrimero(4);
        lista.addPrimero(5);
        lista.addPrimero(6);

        lista.cortar(3);

        System.out.println("Primer elemento: " + lista.obtener(0));
        System.out.println("Ultimo elemnto: " + lista.obtener(lista.size()-1));
        System.out.println("Size: " + lista.size());

    }
}
