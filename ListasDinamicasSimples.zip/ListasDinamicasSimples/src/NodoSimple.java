public class NodoSimple {

    Object valor;
    NodoSimple siguiente;

    public NodoSimple(Object valor){
        this.valor = valor;
        this.siguiente = null;
    }

    public Object obtenerValor(){
        return valor;
    }

    public void enlazarSiguiente(NodoSimple n){
        siguiente = n;
    }

    public NodoSimple obtenerSiguiente(){
        return siguiente;
    }
}
